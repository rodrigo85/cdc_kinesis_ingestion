import json
import base64
from datetime import datetime, timezone, timedelta

MAX_DATA_SIZE = 1024 * 1024  # 1MB

def lambda_handler(event, context):
    records = event['records']
    new_records = []

    for record in records:
        try:
            # Decode and process the data
            data = json.loads(base64.b64decode(record['data']).decode())            
            encoded_data = base64.b64encode(json.dumps(data, default=str).encode()).decode()
            
            if len(encoded_data) > MAX_DATA_SIZE:
                raise ValueError(f"Data size exceeds 1MB for recordId {record['recordId']}")
            
            result = 'Ok'
        except Exception as e:
            print(f"Error processing recordId {record['recordId']}: {e}")
            result = 'Dropped'
            encoded_data = base64.b64encode(json.dumps({"error": str(e)}).encode()).decode()
        
        new_records.append({
            'recordId': str(record['recordId']),
            'result': result,
            'data': encoded_data
        })
    
    return {
        'records': new_records
    }
